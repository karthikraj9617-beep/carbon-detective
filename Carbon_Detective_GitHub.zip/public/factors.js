// Synthetic case coefficients. Columns: source, evidence, quantity, activity unit, coefficient, numerator.
const factors=[
['Stationary combustion','Natural gas metered at the company-operated furnace',10000,'Nm³ gas',2,'kg CO₂e'],
['Mobile combustion','Diesel used in the plant’s own forklifts',1000,'L diesel',2.7,'kg CO₂e'],
['Process emissions','Pure limestone decomposed in a controlled kiln',10,'t CaCO₃ decomposed',0.44,'t CO₂'],
['Fugitive emissions','R-134a released according to the refrigerant mass balance',10,'kg R-134a leaked',1300,'kg CO₂e'],
['Purchased goods and services','Supplier cradle-to-gate footprint for steel castings',200,'t castings',1.8,'t CO₂e'],
['Capital goods','Cradle-to-gate production of a newly acquired press',1,'press purchased',85,'t CO₂e'],
['Fuel- and energy-related activities','Upstream extraction, processing and transport of furnace gas',10000,'Nm³ gas',0.4,'kg CO₂e'],
['Upstream transportation and distribution','Independent carrier delivering inbound parts',12000,'tonne-km',0.08,'kg CO₂e'],
['Waste generated in operations','Wastewater treated by an external operator',2000,'m³ treated',0.3,'kg CO₂e'],
['Business travel','Employee flights for supplier audits',20000,'passenger-km',0.15,'kg CO₂e'],
['Employee commuting','Employee bus journeys to the plant',40000,'passenger-km',0.06,'kg CO₂e'],
['Upstream leased assets','Energy use in a leased depot outside the lessee’s Scope 1 and 2 boundary',15000,'kWh',0.6,'kg CO₂e'],
['Downstream transportation and distribution','Customer-paid road freight of finished pumps after sale',8000,'tonne-km',0.09,'kg CO₂e'],
['Processing of sold products','Customer machining of intermediate castings',200,'t processed',0.1,'t CO₂e'],
['Use of sold products','Expected lifetime electricity used by this year’s sold motors',1800000,'kWh',0.5,'kg CO₂e'],
['End-of-life treatment of sold products','Expected treatment of sold composite parts at disposal',30,'t treated',0.12,'t CO₂e'],
['Downstream leased assets','Power use in a building leased to a tenant outside the owner’s Scope 1 and 2 boundary',60000,'kWh',0.6,'kg CO₂e'],
['Franchises','Power use in independently operated franchise service centres outside the reporting boundary',30000,'kWh',0.6,'kg CO₂e'],
['Investments','Equity investment outside the consolidation boundary: allocate the investee’s relevant emissions by ownership share',500,'t CO₂e investee emissions',0.2,'t CO₂e attributed']
];
