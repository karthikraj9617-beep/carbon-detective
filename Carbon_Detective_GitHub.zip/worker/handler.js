const enc=new TextEncoder();
function zip(files){
 const parts=[],central=[];let offset=0;
 function header(size,fields){let b=new Uint8Array(size),v=new DataView(b.buffer);for(let [i,n,x] of fields)v[n===2?'setUint16':'setUint32'](i,x,true);return b}
 for(const [name,value] of Object.entries(files)){const n=enc.encode(name),b=enc.encode(value);let c=-1;for(const x of b){c^=x;for(let j=0;j<8;j++)c=(c>>>1)^((c&1)?0xedb88320:0)}c=~c;
 const l=header(30,[[0,4,0x04034b50],[4,2,20],[14,4,c],[18,4,b.length],[22,4,b.length],[26,2,n.length]]);
 parts.push(l,n,b);central.push(header(46,[[0,4,0x02014b50],[4,2,20],[6,2,20],[16,4,c],[20,4,b.length],[24,4,b.length],[28,2,n.length],[42,4,offset]]),n);offset+=30+n.length+b.length}
 return new Blob([...parts,...central,header(22,[[0,4,0x06054b50],[8,2,central.length/2],[10,2,central.length/2],[12,4,central.reduce((s,b)=>s+b.length,0)],[16,4,offset]])])
}
const esc=s=>s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;');
export default {async fetch(req,env){const path=new URL(req.url).pathname;
if(path==='/api/register'||path==='/staff/register.xlsx'){
 const db=env.DB;
 if(path.startsWith('/staff')){let secret='';try{secret=atob((req.headers.get('Authorization')||'').split(' ')[1])}catch{}const hash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',enc.encode(secret))),x=>x.toString(16).padStart(2,'0')).join('');if(!env.STAFF_PASSWORD || hash!==Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',enc.encode('staff:'+env.STAFF_PASSWORD))),x=>x.toString(16).padStart(2,'0')).join(''))return new Response('Staff login required',{status:401,headers:{'WWW-Authenticate':'Basic realm="Event staff"','Cache-Control':'no-store'}})}
 await db.prepare('CREATE TABLE IF NOT EXISTS participants(id TEXT PRIMARY KEY, registered TEXT DEFAULT CURRENT_TIMESTAMP, fullName TEXT, company TEXT, email TEXT, industry TEXT, mobile TEXT)').run();
 if(path.startsWith('/api')){if(req.method!=='POST'||!req.headers.get('content-type')?.startsWith('application/json'))return new Response(null,{status:405});const r=await req.json().catch(()=>null);if(!r||!/^[-a-f0-9]{36}$/.test(r.id))return new Response(null,{status:400});const values=['fullName','company','email','industry','mobile'].map(k=>typeof r[k]==='string'?r[k].trim():'');if(values.some((v,i)=>v.length>200||/[\x00-\x1f]/.test(v)||(!v&&i<4))||!/^\S+@\S+\.\S+$/.test(values[2]))return new Response(null,{status:400});await db.prepare('INSERT OR IGNORE INTO participants(id,fullName,company,email,industry,mobile) VALUES(?,?,?,?,?,?)').bind(r.id,...values).run();return new Response(null,{status:204})}
 const {results}=await db.prepare("SELECT date(registered,'+5 hours','+30 minutes') AS day,fullName,company,email,industry,mobile FROM participants ORDER BY rowid").all();const rows=results.map((r,i)=>'<x:row r="'+(i+5)+'">'+['day','fullName','company','email','industry','mobile'].map((k,j)=>'<x:c r="'+'ABCDEF'[j]+(i+5)+'" t="inlineStr"><x:is><x:t>'+esc(r[k])+'</x:t></x:is></x:c>').join('')+'</x:row>').join('');const f={...data.template};const k='xl/worksheets/sheet1.xml';f[k]=f[k].replace('ROWS',()=>rows);return new Response(zip(f),{headers:{'Content-Type':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','Content-Disposition':'attachment; filename="Carbon_Detective_Participants.xlsx"','Cache-Control':'no-store'}})}
 const file=assets[path==='/'?'index.html':path.slice(1)];return file?new Response(Uint8Array.from(atob(file[1]),x=>x.charCodeAt(0)),{headers:{'Content-Type':file[0]}}):new Response('Not found',{status:404})}}
